

# The introduction of visualizing the predictions
### We take the CMR dataset as example
#### Step 1: run `mask_generation.py`
#### Step 2: rum `main.m`

